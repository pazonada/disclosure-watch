import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { StatsBar } from "@/components/stats-bar"
import { DocumentsSection } from "@/components/documents-section"
import { EventsSection } from "@/components/events-section"
import { NewsSection } from "@/components/news-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background grid-bg relative">
      {/* Scanline overlay for tech effect */}
      <div className="fixed inset-0 scanline z-50 pointer-events-none" />
      
      <Header />
      <main>
        <HeroSection />
        <StatsBar />
        <DocumentsSection />
        <EventsSection />
        <NewsSection />
      </main>
      <Footer />
    </div>
  )
}
