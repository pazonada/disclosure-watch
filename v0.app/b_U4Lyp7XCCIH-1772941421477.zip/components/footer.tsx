import { Radio } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-muted/20">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted">
              <Radio className="h-4 w-4 text-lime" />
            </div>
            <span className="text-sm font-display tracking-wide text-foreground uppercase">
              Disclosure Watch
            </span>
          </div>

          {/* Status */}
          <div className="flex items-center gap-4 text-xs font-mono text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-lime animate-pulse" />
              System operational
            </span>
            <span>·</span>
            <span>Last updated: March 7, 2026</span>
          </div>

          {/* Copyright */}
          <p className="text-xs font-mono text-muted-foreground">
            Independent research project · Not affiliated with any government agency
          </p>
        </div>
      </div>
    </footer>
  )
}
