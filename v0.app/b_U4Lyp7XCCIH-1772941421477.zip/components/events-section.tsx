import { Calendar, MapPin, ArrowRight, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const events = [
  {
    type: "Conference",
    status: "Upcoming",
    title: "Contact in the Desert 2026 — World's Largest UAP Conference",
    description: "The annual Contact in the Desert conference returns as the world's largest gathering dedicated to UAP research, disclosure, and contact phenomena.",
    date: "May 28, 2026",
    location: null,
  },
  {
    type: "Deadline",
    status: "Upcoming",
    title: "FY2026 NDAA UAP Briefing Deadline (Estimated)",
    description: "The FY2026 NDAA requires AARO to deliver detailed briefings to Congress on NORTHCOM and NORAD UAP intercepts, including the number, location, and nature of each encounter.",
    date: "Jun 30, 2026",
    location: "Congressional Defense Committees",
  },
]

export function EventsSection() {
  return (
    <section className="border-b border-border/50 py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue/10">
              <Calendar className="h-5 w-5 text-blue" />
            </div>
            <div>
              <h2 className="text-2xl font-display tracking-wide text-foreground uppercase">
                Upcoming Events
              </h2>
              <p className="text-sm text-muted-foreground font-mono">
                Conferences, hearings, and deadlines
              </p>
            </div>
          </div>
          <Button variant="ghost" className="text-muted-foreground hover:text-foreground group">
            View all events
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {events.map((event, index) => (
            <EventCard key={index} {...event} />
          ))}
        </div>
      </div>
    </section>
  )
}

function EventCard({
  type,
  status,
  title,
  description,
  date,
  location,
}: {
  type: string
  status: string
  title: string
  description: string
  date: string
  location: string | null
}) {
  return (
    <article className="group relative flex gap-4 rounded-lg border border-border/50 bg-card p-5 transition-all hover:border-blue/30 hover:bg-muted/30">
      {/* Date badge */}
      <div className="flex-shrink-0">
        <div className="flex flex-col items-center justify-center w-16 h-16 rounded-lg bg-blue/10 border border-blue/20">
          <span className="text-xs font-mono text-blue uppercase">
            {date.split(" ")[0]}
          </span>
          <span className="text-xl font-bold text-foreground">
            {date.split(" ")[1]?.replace(",", "")}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="outline" className="text-xs font-mono bg-blue/5 text-blue border-blue/20">
            {status}
          </Badge>
          <Badge variant="outline" className="text-xs font-mono bg-muted/50">
            {type}
          </Badge>
        </div>

        <h3 className="text-base font-semibold text-foreground leading-snug mb-2 group-hover:text-blue transition-colors line-clamp-2">
          {title}
        </h3>
        
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2">
          {description}
        </p>

        <div className="mt-3 flex flex-wrap items-center gap-3 text-xs font-mono text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5" />
            {date}
          </span>
          {location && (
            <span className="flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5" />
              {location}
            </span>
          )}
        </div>
      </div>

      {/* Hover indicator */}
      <a 
        href="#" 
        className="absolute inset-0 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue/50"
        aria-label={`View ${title}`}
      />
    </article>
  )
}
