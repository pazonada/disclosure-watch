import { Newspaper, ExternalLink } from "lucide-react"

const newsItems = [
  { title: "Trump orders Pentagon, federal agencies to release files on UFOs and aliens", date: "Feb 20, 2026", source: "Stars and Stripes" },
  { title: "Trump says he doesn't know if aliens are real but directs government to release files", date: "Feb 20, 2026", source: "NPR" },
  { title: "We asked scientists what they think we'll learn from the government's UFO files", date: "Feb 20, 2026", source: "CBS News" },
  { title: "Trump's order to release evidence for aliens obscures the scientific search for extraterrestrial life", date: "Feb 21, 2026", source: "Scientific American" },
  { title: "Trump orders UFO disclosure: What does it mean for us?", date: "Feb 21, 2026", source: "Psychology Today" },
  { title: "Washington promises UFO disclosure. History suggests otherwise.", date: "Feb 22, 2026", source: "Nextgov/FCW" },
  { title: "Congressman questions alleged massive overseas UAP structure", date: "Feb 24, 2026", source: "Cybernews" },
  { title: "Hegseth shares update on government release of UFO files", date: "Feb 25, 2026", source: "TIME" },
  { title: "Hegseth doubles down on Trump's UAP disclosure promise as AARO's caseload exceeds 2,000", date: "Feb 25, 2026", source: "DefenseScoop" },
  { title: "Congress shown classified UAP videos that 'defy physics,' lawmaker says", date: "Feb 28, 2026", source: "Cybernews" },
  { title: "American Airlines pilots perplexed after witnessing 'super bright' UFOs over Texas", date: "Mar 2, 2026", source: "Simple Flying" },
  { title: "Trump vowed to release government files on aliens and UFOs — why haven't they been publicized yet?", date: "Mar 7, 2026", source: "CNN" },
]

export function NewsSection() {
  return (
    <section className="py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
            <Newspaper className="h-5 w-5 text-foreground" />
          </div>
          <div>
            <h2 className="text-2xl font-display tracking-wide text-foreground uppercase">
              News & Media
            </h2>
            <p className="text-sm text-muted-foreground font-mono">
              External coverage from trusted outlets
            </p>
          </div>
        </div>

        <div className="rounded-lg border border-border/50 bg-card overflow-hidden">
          <ul className="divide-y divide-border/50">
            {newsItems.map((item, index) => (
              <li key={index}>
                <a 
                  href="#"
                  className="group flex items-center justify-between gap-4 px-5 py-4 transition-colors hover:bg-muted/30"
                >
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-medium text-foreground group-hover:text-lime transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                    <p className="mt-1 text-xs font-mono text-muted-foreground">
                      {item.date} · {item.source}
                    </p>
                  </div>
                  <ExternalLink className="h-4 w-4 flex-shrink-0 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:text-lime transition-all" />
                </a>
              </li>
            ))}
          </ul>
        </div>

        <p className="mt-4 text-xs text-muted-foreground text-center font-mono">
          External sources. Disclosure Watch is not affiliated with any of these outlets.
        </p>
      </div>
    </section>
  )
}
