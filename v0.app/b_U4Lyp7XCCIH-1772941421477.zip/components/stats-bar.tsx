import { FileText, Calendar, Newspaper, Radio } from "lucide-react"

const stats = [
  { icon: FileText, value: "44", label: "Documents", color: "text-lime" },
  { icon: Calendar, value: "27", label: "Events", color: "text-blue" },
  { icon: Newspaper, value: "34", label: "News Items", color: "text-foreground" },
  { icon: Radio, value: "25+", label: "Sources", color: "text-muted-foreground" },
]

export function StatsBar() {
  return (
    <section className="border-b border-border/50 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 sm:gap-8">
          {stats.map((stat) => (
            <div key={stat.label} className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-background border border-border/50">
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div>
                <p className={`text-2xl font-bold tracking-tight ${stat.color}`}>
                  {stat.value}
                </p>
                <p className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  {stat.label}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
