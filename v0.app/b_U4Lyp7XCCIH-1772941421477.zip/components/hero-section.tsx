import { AlertTriangle, FileText, Calendar, Newspaper } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden border-b border-border/50">
      {/* Gradient accent */}
      <div className="absolute inset-0 bg-gradient-to-br from-lime/5 via-transparent to-blue/5" />
      
      <div className="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
          {/* Left column - Main content */}
          <div className="flex flex-col justify-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1.5 text-xs font-mono text-muted-foreground w-fit mb-6">
              <AlertTriangle className="h-3.5 w-3.5 text-lime" />
              <span>STATE OF DISCLOSURE</span>
              <span className="text-border">|</span>
              <span className="text-foreground">Week of March 2, 2026</span>
            </div>
            
            <h1 className="text-3xl font-display tracking-wide text-foreground sm:text-4xl lg:text-5xl text-balance uppercase">
              Your weekly intelligence briefing on{" "}
              <span className="text-lime">UAP disclosure</span> activity.
            </h1>
            
            <p className="mt-6 text-base text-muted-foreground leading-relaxed lg:text-lg">
              Two weeks since Trump{"'"}s declassification directive and CNN is already asking: where are the files? 
              American Airlines pilots reported bright unidentified objects over Texas this week, drawing fresh FAA attention, 
              while the DoD Inspector General{"'"}s heavily redacted whistleblower reprisal report from January continues 
              to fuel demands for stronger protections.
            </p>
            
            <p className="mt-4 text-base text-muted-foreground leading-relaxed lg:text-lg">
              We{"'"}re now tracking <span className="text-lime font-semibold">44 documents</span>,{" "}
              <span className="text-blue font-semibold">27 events</span>, and{" "}
              <span className="text-foreground font-semibold">34 news items</span> across 25+ sources.
            </p>
          </div>
          
          {/* Right column - Quick stats cards */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
            <QuickStatCard
              icon={FileText}
              label="Latest document"
              title="DoD Inspector General UAP Whistleblower Reprisal Report"
              date="Jan 7, 2026"
              stat="39 total tracked"
              accent="lime"
            />
            <QuickStatCard
              icon={Calendar}
              label="Upcoming event"
              title="Contact in the Desert 2026 — World's Largest UAP Conference"
              date="May 28, 2026"
              stat="27 total tracked"
              accent="blue"
            />
            <QuickStatCard
              icon={Newspaper}
              label="Latest milestone"
              title="Hegseth Reaffirms UAP Disclosure Commitment"
              date="Feb 25, 2026"
              stat="36 total tracked"
              accent="lime"
              className="sm:col-span-2 lg:col-span-1 xl:col-span-2"
            />
          </div>
        </div>
      </div>
    </section>
  )
}

function QuickStatCard({
  icon: Icon,
  label,
  title,
  date,
  stat,
  accent,
  className = "",
}: {
  icon: React.ElementType
  label: string
  title: string
  date: string
  stat: string
  accent: "lime" | "blue"
  className?: string
}) {
  const accentClasses = {
    lime: "border-l-lime bg-lime/5",
    blue: "border-l-blue bg-blue/5",
  }
  
  return (
    <div className={`rounded-lg border border-border/50 ${accentClasses[accent]} border-l-2 p-4 transition-colors hover:bg-muted/50 ${className}`}>
      <div className="flex items-start gap-3">
        <div className={`rounded-md p-2 ${accent === "lime" ? "bg-lime/10" : "bg-blue/10"}`}>
          <Icon className={`h-4 w-4 ${accent === "lime" ? "text-lime" : "text-blue"}`} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
            {label}
          </p>
          <h3 className="mt-1 text-sm font-semibold text-foreground line-clamp-2">
            {title}
          </h3>
          <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground font-mono">
            <span>{date}</span>
            <span className="text-border">·</span>
            <span>{stat}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
