"use client"

import { Radio } from "lucide-react"

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-lg bg-muted glow-primary-sm">
            <Radio className="h-5 w-5 text-lime" />
            <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-lime animate-pulse" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-display tracking-wide text-foreground">
              DISCLOSURE WATCH
            </span>
            <span className="text-xs text-muted-foreground tracking-wider uppercase">
              UAP Intelligence Dashboard
            </span>
          </div>
        </div>

        {/* Status indicator */}
        <div className="hidden sm:flex items-center gap-4">
          <div className="flex items-center gap-2 rounded-full bg-muted px-3 py-1.5 text-xs font-mono">
            <span className="h-2 w-2 rounded-full bg-lime animate-pulse" />
            <span className="text-muted-foreground">LIVE</span>
            <span className="text-foreground">·</span>
            <span className="text-muted-foreground">25+ sources</span>
          </div>
        </div>
      </div>
    </header>
  )
}
