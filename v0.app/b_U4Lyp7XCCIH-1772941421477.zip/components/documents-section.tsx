import { FileText, ExternalLink, ArrowRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const documents = [
  {
    type: "Report",
    priority: "Critical",
    title: "DoD Inspector General UAP Whistleblower Reprisal Report",
    description: "The Department of Defense Inspector General released a heavily redacted final report on UAP-related whistleblower reprisal investigations, centering on the revocation of classified access from individuals who reported UAP information to Congress.",
    date: "Jan 7, 2026",
    tags: ["DoD IG", "Whistleblower", "Reprisal"],
  },
  {
    type: "Report",
    priority: "Critical",
    title: "FY2026 NDAA Mandates Pentagon UAP Briefings to Congress",
    description: "The fiscal year 2026 National Defense Authorization Act directs the AARO director to provide Congress with briefings and data on the number, location, and nature of any UAP intercepts by NORTHCOM and NORAD.",
    date: "Dec 10, 2025",
    tags: ["NDAA", "Congress", "NORTHCOM"],
  },
  {
    type: "Report",
    priority: "High",
    title: "FAA Updates UAP Reporting Procedures and Terminology",
    description: "The FAA issued updated notices formalizing UAP reporting procedures for all Air Traffic Control personnel, requiring notification to National Tactical Security Operations and adding AARO website references.",
    date: "Oct 26, 2025",
    tags: ["FAA", "ATC", "Reporting"],
  },
]

export function DocumentsSection() {
  return (
    <section className="border-b border-border/50 py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-lime/10 glow-primary-sm">
              <FileText className="h-5 w-5 text-lime" />
            </div>
            <div>
              <h2 className="text-2xl font-display tracking-wide text-foreground uppercase">
                Latest Documents
              </h2>
              <p className="text-sm text-muted-foreground font-mono">
                Official releases and reports
              </p>
            </div>
          </div>
          <Button variant="ghost" className="text-muted-foreground hover:text-foreground group">
            View all documents
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          {documents.map((doc, index) => (
            <DocumentCard key={index} {...doc} />
          ))}
        </div>
      </div>
    </section>
  )
}

function DocumentCard({
  type,
  priority,
  title,
  description,
  date,
  tags,
}: {
  type: string
  priority: string
  title: string
  description: string
  date: string
  tags: string[]
}) {
  const priorityStyles = {
    Critical: "bg-destructive/10 text-destructive border-destructive/20",
    High: "bg-chart-4/10 text-chart-4 border-chart-4/20",
  }

  return (
    <article className="group relative flex flex-col rounded-lg border border-border/50 bg-card p-5 transition-all hover:border-lime/30 hover:bg-muted/30">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs font-mono bg-muted/50">
            {type}
          </Badge>
          <Badge 
            variant="outline" 
            className={`text-xs font-mono ${priorityStyles[priority as keyof typeof priorityStyles] || ""}`}
          >
            {priority}
          </Badge>
        </div>
        <FileText className="h-4 w-4 text-muted-foreground" />
      </div>

      {/* Content */}
      <h3 className="text-base font-semibold text-foreground leading-snug mb-2 line-clamp-2 group-hover:text-lime transition-colors">
        {title}
      </h3>
      <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 flex-1">
        {description}
      </p>

      {/* Footer */}
      <div className="mt-4 pt-4 border-t border-border/50">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono text-muted-foreground">{date}</span>
          <div className="flex items-center gap-1.5">
            {tags.slice(0, 2).map((tag) => (
              <span 
                key={tag} 
                className="text-xs font-mono text-muted-foreground bg-muted/50 px-2 py-0.5 rounded"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Hover link */}
      <a 
        href="#" 
        className="absolute inset-0 rounded-lg focus:outline-none focus:ring-2 focus:ring-lime/50"
        aria-label={`View ${title}`}
      >
        <span className="sr-only">View source</span>
      </a>
      
      <div className="absolute bottom-5 right-5 opacity-0 group-hover:opacity-100 transition-opacity">
        <ExternalLink className="h-4 w-4 text-lime" />
      </div>
    </article>
  )
}
